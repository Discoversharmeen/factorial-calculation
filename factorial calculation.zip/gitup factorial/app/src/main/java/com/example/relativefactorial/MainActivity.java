package com.example.relativefactorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
 private EditText edit02;
 private Button button03;
 private TextView result04;

 @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button03 = findViewById(R.id.button03);
        button03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit02 = findViewById(R.id.edit02);
                int edit = Integer.parseInt(edit02.getText().toString());
                int ddd = 1;
                for (int i = edit; i >= 1; i--) {
                    ddd *= 1;
                }
                result04.setText("Factorial : + ddd");

            }
        });
    }
}